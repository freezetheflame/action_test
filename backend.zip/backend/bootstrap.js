const { Bootstrap } = require('@midwayjs/bootstrap');
Bootstrap.run();
